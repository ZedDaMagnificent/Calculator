﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MyCalculator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        double num1, num2, result;

        private void btnTimes_Click(object sender, EventArgs e)
        {
            try
            {
                num1 = Double.Parse(txtNumber1.Text);
                num2 = Double.Parse(txtNumber2.Text);
                result = num1 * num2;
                txtAnswer.Text = result.ToString();
            }
            catch
            {
                MessageBox.Show("Error : Please ensure Number 1 & 2 are enter correctly with numbers only");
            }
        }

        private void btnDivide_Click(object sender, EventArgs e)
        {
            try
            {
                num1 = Double.Parse(txtNumber1.Text);
                num2 = Double.Parse(txtNumber2.Text);
                result = num1 / num2;
                txtAnswer.Text = result.ToString();
            }
            catch
            {
                MessageBox.Show("Error : Please ensure Number 1 & 2 are enter correctly with numbers only");
            }
        }

        private void btnMinus_Click(object sender, EventArgs e)
        {
            try
            {
                num1 = Double.Parse(txtNumber1.Text);
                num2 = Double.Parse(txtNumber2.Text);
                result = num1 - num2;
                txtAnswer.Text = result.ToString();
            }
            catch
            {
                MessageBox.Show("Error : Please ensure Number 1 & 2 are enter correctly with numbers only");
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                num1 = Double.Parse(txtNumber1.Text);
                num2 = Double.Parse(txtNumber2.Text);
                result = num1 + num2;
                txtAnswer.Text = result.ToString();
            }
            catch
            {
                MessageBox.Show("Error : Please ensure Number 1 & Number 2 are enter correctly with numbers only");
                return;
            }
        }
    }
}
